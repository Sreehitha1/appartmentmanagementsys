export const URL = "http://localhost:9000/api";
// export const IF = "http://localhost:9000/uploads/"